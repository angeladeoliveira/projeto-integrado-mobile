import React, {useContext} from 'react';
import {NavigationContainer} from '@react-navigation/native'
import {createNativeStackNavigator} from '@react-navigation/native-stack'
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs'

import {AuthContext} from '../contexts/AuthContext'
import Login from '../screens/Login'
import Home from '../screens/Home'
import Cadastro from '../screens/Cadastro'
import Fornecedores from '../screens/Fornecedores'
import CadastrarFornecedor from '../screens/CadastrarFornecedor'
import EditarFornecedor from '../screens/EditarFornecedor'
import DetalheFornecedor from '../screens/DetalheFornecedor'


const Stack = createNativeStackNavigator()

export default function MainNavigator() {
  const [logado] = useContext(AuthContext)
  return (
    <NavigationContainer>
      {!logado
      ? <Stack.Navigator>
           <Stack.Screen name='login' options={{headerShown: false}} component={Login} />
           <Stack.Screen name='cadastro' options={{headerShown: false}} component={Cadastro} />
        </Stack.Navigator>
      : <Stack.Navigator>
          <Stack.Screen name='home' options={{headerShown: false}} component={Home} />
          <Stack.Screen name='fornecedores' options={{headerShown: false}} component={Fornecedores} />
          <Stack.Screen name='cadFornecedor' options={{headerShown: false}} component={CadastrarFornecedor} />
          <Stack.Screen name='detFornecedor' options={{headerShown: false}} component={DetalheFornecedor} />
          <Stack.Screen name='editFornecedor' options={{headerShown: false}} component={EditarFornecedor} />
      </Stack.Navigator>
      }
    </NavigationContainer>
  );
}
