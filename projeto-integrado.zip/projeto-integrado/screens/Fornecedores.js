import React from 'react';
import { Text, View, Button, Image, TextInput, Pressable, StyleSheet } from 'react-native';

import ItemFornecedor from '../components/ItemFornecedor'


export default function Fornecedores({navigation}) {
  return (
    <View style={{backgroundColor: 'white', height: "100%"}}>
      <View style={{flex: 9, padding: 8}}>
        <View style={{flexDirection: 'row', paddingTop: 56, alignItems: 'center', marginBottom: 32, width: '100%'}}>
          <Pressable style={{flex: 1}} onPress={()=> navigation.goBack()}>
          <Image style={{height: 26, width: 26}} source={require('../assets/Back.png')} />
          </Pressable>
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 24, paddingLeft: 16, flex:10}}>Fornecedores</Text>

          <Pressable onPress={()=> navigation.navigate('cadFornecedor')} style={{alignItems: 'flex-end', flex: 3, paddingRight: 8}}>
            <Image style={{height: 26, width: 26}} source={require('../assets/Add.png')} />
          </Pressable>
        </View>

        <Pressable onPress={()=> navigation.navigate('detFornecedor')}>
          <ItemFornecedor nome="Ana Amorim" telefone="(xx) xxxxx-xxxx" categoria="Cerimonial" />
        </Pressable>
        <Pressable onPress={()=> navigation.navigate('detFornecedor')}>
          <ItemFornecedor nome="Gusttavo Damásio" telefone="(xx) xxxxx-xxxx" categoria="Decoração" />
        </Pressable>
        <Pressable onPress={()=> navigation.navigate('detFornecedor')}>
          <ItemFornecedor nome="Viva Pão de Mel" telefone="(xx) xxxxx-xxxx" categoria="Lembrança" />
        </Pressable>

      </View>
      
      <View style={{flex: 1, justifyContent: "flex-end"}}>
        <View style={{height: 96, borderTopLeftRadius: 32, borderTopRightRadius: 32, borderColor: "#EBEEF2", borderWidth: 2, justifyContent: "space-evenly", alignItems:"center", flexDirection: "row" }}>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('home')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/Home.png')} />
          </Pressable>
          <Pressable style={styles.ativo}  onPress={()=> navigation.navigate('fornecedores')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/SupplierOn.png')} />
          </Pressable>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('cadFornecedor')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/AddSupplier.png')} />
          </Pressable>
        </View>
      </View>
      
    </View>
  );
}

const styles = StyleSheet.create({
    ativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#F27272", 
      justifyContent: "center", 
      alignItems: "center"
    }, 
    inativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#FEEFEF", 
      justifyContent: "center", 
      alignItems: "center"
    }  
  })
