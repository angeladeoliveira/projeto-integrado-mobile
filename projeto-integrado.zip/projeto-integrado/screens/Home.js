import React, {useContext} from 'react';
import { Text, View, Button, Image, Pressable, StyleSheet } from 'react-native';
import { useFonts, Roboto_400Regular, Roboto_500Regular } from '@expo-google-fonts/roboto';

import {AuthContext} from '../contexts/AuthContext'
import HomeList from '../components/HomeList'


export default function Home({navigation}) {
    const [logado, setLogado] = useContext(AuthContext)
  return (
    <View style={{backgroundColor: 'white', height: "100%"}}>
      <View style={{flex: 9, padding: 8}}>
        <View style={{flexDirection: 'row', paddingTop: 56, alignItems: 'center', marginBottom: 32}}>
          <Image style={{height: 26, width: 26}} source={require('../assets/weddly-logo.png')} />
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 24, paddingLeft: 8}}>Weddly</Text>
          <Pressable onPress={() => setLogado(false)} style={{alignItems: 'flex-end', flex: 3, paddingRight: 8}}>
            <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, color: '#F27272', right: 16 }}>Sair</Text>
          </Pressable>
        </View>
        <Pressable onPress={()=> navigation.navigate('fornecedores')}>
        <View style={{borderRadius: 16, borderWidth: 2, borderColor: '#EBEEF2', height: 96, padding: 8, flexDirection:'row', alignItems: 'center'}}>
          <Image style={{ height: 72, width: 72}} source={require('../assets/supplier-logo.png')} />
          <Text style={{paddingLeft: 13, maxWidth: "70%"}}>Veja de forma resumida todos os fornecedores do seu casamento e adicione novos.</Text>
        </View>
        </Pressable>
      </View>

      <View style={{flex: 1, justifyContent: "flex-end"}}>
        <View style={{height: 96, borderTopLeftRadius: 32, borderTopRightRadius: 32, borderColor: "#EBEEF2", borderWidth: 2, justifyContent: "space-evenly", alignItems:"center", flexDirection: "row" }}>
          <Pressable style={styles.ativo}  onPress={()=> navigation.navigate('home')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/HomeOn.png')} />
          </Pressable>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('fornecedores')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/Supplier.png')} />
          </Pressable>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('cadFornecedor')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/AddSupplier.png')} />
          </Pressable>
        </View>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
    ativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#F27272", 
      justifyContent: "center", 
      alignItems: "center"
    }, 
    inativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#FEEFEF", 
      justifyContent: "center", 
      alignItems: "center"
    }  
  })