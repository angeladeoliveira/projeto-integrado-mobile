import React, {useContext} from 'react';
import { Text, View, Button, Image, TextInput, Pressable } from 'react-native';

import {AuthContext} from '../contexts/AuthContext'
import MandatoryInputLabel from '../components/MandatoryInputLabel'
import LargeInput from '../components/LargeInput'
import FullWidthButton from '../components/FullWidthButton'

export default function Cadastro({navigation}) {
  const [logado, setLogado] = useContext(AuthContext)
  return (
    <View style={{ flex: 1, backgroundColor: '#FFFFFF', padding: 8}}>
      <View style={{flexDirection: 'row', paddingTop: 56, alignItems: 'center', marginBottom: 32, width: '100%'}}>
        <Pressable style={{flex: 1}} onPress={()=> navigation.navigate('login')}>
        <Image style={{height: 26, width: 26}} source={require('../assets/Back.png')} />
        </Pressable>
        <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 24, paddingLeft: 16, flex:10}}>Novo Usuário</Text>

        <Pressable onPress={() => setLogado(true)} style={{alignItems: 'flex-end', flex: 3, paddingRight: 8}}>
          <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, color: '#F27272', right: 16 }}>Salvar</Text>
        </Pressable>
      </View>
      <View style={{borderColor: '#EBEEF2', borderWidth: 2, borderRadius: 16, paddingVertical: 16, paddingHorizontal: 8}}>
        <MandatoryInputLabel label='Nome' />
        <LargeInput placeholder='Seu nome' kbtype='default'/>
        <MandatoryInputLabel label='Email' />
        <LargeInput placeholder='example@example.com' kbtype='email-address'/>
        <MandatoryInputLabel label='Senha' />
        <LargeInput placeholder='Sua senha' kbtype='default' senha='true' />
        <MandatoryInputLabel label='Confirme a senha' />
        <LargeInput placeholder='Sua senha novamente' kbtype='default' senha='true' />
      </View>
      
      
    </View>
  );
}
