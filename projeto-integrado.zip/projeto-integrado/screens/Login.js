import React, {useContext} from 'react';
import { Text, View, Button, Image, TextInput, Pressable } from 'react-native';

import {AuthContext} from '../contexts/AuthContext'
import MandatoryInputLabel from '../components/MandatoryInputLabel'
import LargeInput from '../components/LargeInput'
import FullWidthButton from '../components/FullWidthButton'

export default function Login({navigation}) {
  const [logado, setLogado] = useContext(AuthContext)
  return (
    <View style={{ flex: 1, justifyContent: 'center', backgroundColor: '#FFFFFF', padding: 8}}>
      <View style={{alignItems: 'center'}}>
        <Image style={{height: 112, width: 112, marginBottom: 32}} source={require('../assets/weddly-logo.png')} />
      </View>
      
      <MandatoryInputLabel label='Email' />
      <LargeInput placeholder='example@example.com' kbtype='email-address'/>
      <MandatoryInputLabel label='Senha' />
      <LargeInput placeholder='Sua senha' kbtype='default' senha='true' />
      
      <Pressable style={{backgroundColor: '#F27272', width: '100%', borderRadius: 32, height: 48, alignItems: 'center', justifyContent: 'center' }} onPress={() => setLogado(true)}>
        <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, color: '#FFFFFF'}}>Fazer login</Text>
      </Pressable>
      
      <View style={{flexDirection: 'row', marginTop: 32, justifyContent:'center'}}>
        <Text style={{fontFamily: 'Roboto_400Regular', fontWeight: '300', fontSize: 16}}>Não tem uma conta? </Text> 
        <Pressable onPress={()=> navigation.navigate('cadastro')}>
          <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, color: '#F27272' }}>Crie agora gratuitamente</Text>
        </Pressable>
      </View>
    </View>
  );
}
