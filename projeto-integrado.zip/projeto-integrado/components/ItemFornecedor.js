import React from 'react';
import { Text, View, Pressable, Image } from 'react-native';

export default function ItemFornecedor(props) {
  return (
    <View style={{borderBottomWidth: 2, borderTopWidth: 2, borderColor: '#EBEEF2', height: 96, padding: 8, flexDirection:'row', alignItems: 'center', marginBottom: -2}}>
            <View style={{flex: 7}}>
              <Text style={{fontFamily: 'Roboto_500Regular', fontWeight: 'bold', fontSize: 16, marginBottom: 8}}>{props.nome}</Text>
              <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 16}}>{props.telefone}</Text>
            </View>
            <View style={{flex: 3, borderRadius: 32, borderWidth: 2, borderColor: '#F27272', height: 32, width: 88, justifyContent: "center", alignItems: "center", padding: 4}}>
              <Text style={{color: "#F27272", fontSize: 14}}>{props.categoria}</Text>
            </View>
            <View style={{ flex: 1, alignItems: "flex-end", justifyContent: "center"}}>
                <Image style={{height: 16, width: 16}} source={require('../assets/Forward.png')} />
            </View>
          </View>
  );
}


