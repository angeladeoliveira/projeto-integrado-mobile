import React from 'react';
import { Text, View, Image } from 'react-native';
import { useFonts, Roboto_400Regular, Roboto_500Regular } from '@expo-google-fonts/roboto';



export default function HomeList(props) {
  return (
      <View style={{borderRadius: 16, borderWidth: 2, borderColor: '#EBEEF2', height: 96, padding: 8, flexDirection:'row', alignItems: 'center'}}>
        <Image style={{ height: 72, width: 72}} source={require(`${props.img}`)} />
        <Text style={{paddingLeft: 13}}>{props.texto}</Text>
      </View>

  );
}
