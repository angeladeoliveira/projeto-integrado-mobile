import React, {useContext} from 'react';
import { Text, Pressable } from 'react-native';


export default function FullWidthWarningButton(props) {

  return (
      <Pressable style={{backgroundColor: '#FEEFEF', width: '100%', borderRadius: 32, height: 48, alignItems: 'center', justifyContent: 'center' }} onPress={()=> props.path}>
      <Text style={{fontFamily: 'Roboto', fontSize: 16, color: '#DA1414'}}>{props.texto}</Text>
      </Pressable>

  );
}
