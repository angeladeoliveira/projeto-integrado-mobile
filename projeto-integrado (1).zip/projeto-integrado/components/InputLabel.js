import React from 'react';
import { Text, View } from 'react-native';

export default function InputLabel(props) {
  return (
    <View style={{flexDirection: "row", paddingBottom: 4}}>
    <Text style={{fontFamily: 'Roboto', fontSize: 12, color: '#3F444E', marginLeft: 24}}>{props.label}</Text>
    </View>
  );
}
