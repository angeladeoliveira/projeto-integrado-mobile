import React from 'react';
import { Text, View, TextInput} from 'react-native';

export default function LargeInput(props) {
  return (
    <TextInput
      style={{paddingVertical: 8,
      paddingHorizontal: 24,
      marginBottom: 16,
      borderWidth: 2,
      borderColor: '#A8ABAF',
      borderRadius: 32,
      width: '100%',
      height: 42}}
      placeholder={props.placeholder} 
      placeholderTextColor='#A8ABAF'
      keyboardType={props.kbtype}
      secureTextEntry={props.senha}

/>
  );
}
