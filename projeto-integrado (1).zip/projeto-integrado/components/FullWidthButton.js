import React, {useContext} from 'react';
import { Text, Pressable } from 'react-native';

import {AuthContext} from '../contexts/AuthContext'


export default function FullWidthButton(props) {
  const [logado, setLogado] = useContext(AuthContext)
  return (
      <Pressable style={{backgroundColor: '#F27272', width: '100%', borderRadius: 32, height: 48, alignItems: 'center', justifyContent: 'center' }} onPress={() => setLogado(true)}>
      <Text style={{fontFamily: 'Roboto', fontSize: 16, color: '#FFFFFF'}}>{props.texto}</Text>
      </Pressable>

  );
}
