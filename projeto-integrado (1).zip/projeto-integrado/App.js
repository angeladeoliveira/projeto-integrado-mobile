import React, {useState, useEffect} from 'react';
import { useFonts, Roboto_400Regular } from '@expo-google-fonts/roboto';

import {AuthProvider} from './contexts/AuthContext'

import Splash from './screens/Splash'
import MainNavigator from './routes/MainNavigator'

export default function App() {

  const [exibeSplash, setExibeSplash] = useState(true)

  useEffect(() => {
    setTimeout(() => setExibeSplash(false), 4000);
  }, [])

  return (
    <AuthProvider>
      {exibeSplash ? <Splash /> : <MainNavigator />}
    </AuthProvider>
  );
}

