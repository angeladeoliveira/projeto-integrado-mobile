import React from 'react';
import { Text, View, Image } from 'react-native';

export default function Splash() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#FFFFFF' }}>
      <Image style={{height: 160, width: 160}} source={require('../assets/weddly-logo.jpg')} />
    </View>
  );
}
