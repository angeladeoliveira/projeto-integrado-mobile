import React, {useState} from 'react';
import { Text, View, Button, Image, TextInput, Pressable, StyleSheet, Modal, Alert } from 'react-native';

import InputLabel from '../components/InputLabel'
import MandatoryInputLabel from '../components/MandatoryInputLabel'
import LargeFilledInput from '../components/LargeFilledInput'
import FullWidthWarningButton from '../components/FullWidthWarningButton'

export default function EditarFornecedor({navigation}) {

  const [modalVisible, setModalVisible] = useState(false)
  const [modal2Visible, setModal2Visible] = useState(false)

  const [nome, setNome] = useState("Ana Amorim")
  const [categoria, setCategoria] = useState("Cerimonial")
  const [telefone, setTelefone] = useState("(xx) xxxxx-xxxx")
  const [email, setEmail] = useState("exemplo@exemplo.com")

  return (
    <View style={{backgroundColor: 'white', height: "100%"}}>
      <View style={{flex: 9, padding: 8}}>
    
      <Modal animationType="none" transparent={true} visible={modalVisible} onRequestClose={() => {setModalVisible(!modalVisible)}}>
        <View style={{backgroundColor: "rgba(179, 183, 189, 0.4)", flex: 1, justifyContent: "center", alignItems: "center"}}>
          <View style={{backgroundColor: "#FF6861", width: 232, height: 264, borderRadius: 16, margin: 20, shadowColor: "#000", shadowOffset: {width: 0,height: 2}, shadowOpacity: 0.25, shadowRadius: 4, elevation: 5, justifyContent: "center", alignItems: "center"}}>
              <Image style={{height: 56, width: 56}} source={require('../assets/Delete.png')} />

            <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, lineHeight: 20, color: "#FFFFFF", paddingTop: 24, paddingHorizontal: 40, paddingBottom: 30, textAlign: "center"}}>Você tem certeza que deseja deletar esse fornecedor?</Text>
            <View style={{flexDirection: "row"}}>
            <Pressable style={{borderRadius: 32, width: 88, height: 32, elevation: 2, backgroundColor: "#EFA8A4", alignItems: "center", justifyContent: "center", marginRight: 16 }} onPress={() => setModalVisible(!modalVisible)}>
              <Text style={{color: "#FFFFFF", fontSize: 14, lineHeight: 17.5, fontFamily: 'Roboto_400Regular'}}>Cancelar</Text>
            </Pressable>
            <Pressable style={{borderRadius: 32, width: 88, height: 32, elevation: 2, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" }} onPress={() => [setModal2Visible(!modal2Visible), setModalVisible(!modalVisible)]}>
              <Text style={{color: "#FF6861", fontSize: 14, lineHeight: 17.5, fontFamily: 'Roboto_400Regular'}}>Sim</Text>
            </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal animationType="none" transparent={true} visible={modal2Visible} onRequestClose={() => setModal2Visible(!modal2Visible)}>
        <Pressable onPress={() => navigation.navigate('fornecedores')} style={{flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(179, 183, 189, 0.4)"}}>
          <View style={{backgroundColor: "#FF6861", width: 232, height: 264, borderRadius: 16, margin: 20, shadowColor: "#000", shadowOffset: {width: 0,height: 2}, shadowOpacity: 0.25, shadowRadius: 4, elevation: 5, justifyContent: "center", alignItems: "center"}}>
              <Image style={{height: 56, width: 56}} source={require('../assets/Delete.png')} />

            <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, lineHeight: 20, color: "#FFFFFF", paddingTop: 24, paddingHorizontal: 40, paddingBottom: 30, textAlign: "center"}}>Fornecedor deletado com sucesso</Text>
          </View>
        </Pressable>
      </Modal>


        <View style={{flexDirection: 'row', paddingTop: 56, alignItems: 'center', marginBottom: 32, width: '100%'}}>
          <Pressable style={{flex: 1}} onPress={()=> navigation.goBack()}>
            <Image style={{height: 26, width: 26}} source={require('../assets/Back.png')} />
          </Pressable>
          
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 24, paddingLeft: 16, flex:10}}>Editar fornecedor</Text>

          <Pressable onPress={()=> navigation.navigate('detFornecedor')} style={{alignItems: 'flex-end', flex: 3, paddingRight: 8}}>
            <Text style={{fontFamily: 'Roboto_400Regular', fontSize: 16, color: '#F27272', right: 16 }}>Salvar</Text>
          </Pressable>
        
        </View>

        <View style={{borderColor: '#EBEEF2', borderWidth: 2, borderRadius: 16, paddingVertical: 16, paddingHorizontal: 8}}>
          <MandatoryInputLabel label='Nome do fornecedor' />
          <LargeFilledInput placeholder='Digite o nome do fornecedor' kbtype='default' onChangeText={setNome} value={nome} />
          <MandatoryInputLabel label='Categoria' />
          <LargeFilledInput placeholder='Digite uma categoria' kbtype='default' onChangeText={setCategoria} value={categoria} />
          <InputLabel label='Telefone' />
          <LargeFilledInput placeholder="(xx) xxxxx-xxxx" kbtype='phone-pad' onChangeText={setTelefone} value={telefone}  />
          <InputLabel label='Email' />
          <LargeFilledInput placeholder='exemplo@exemplo.com' kbtype='email-address' onChangeText={setEmail} value={email} />
          
          <Pressable style={{backgroundColor: '#FEEFEF', width: '100%', borderRadius: 32, height: 48, alignItems: 'center', justifyContent: 'center' }} onPress={() => setModalVisible(true)}>
          <Text style={{fontFamily: 'Roboto', fontSize: 16, color: '#DA1414'}}>Deletar o fornecedor</Text>
          </Pressable>
        </View>

      </View>
      

      <View style={{flex: 1, justifyContent: "flex-end"}}>
        <View style={{height: 96, borderTopLeftRadius: 32, borderTopRightRadius: 32, borderColor: "#EBEEF2", borderWidth: 2, justifyContent: "space-evenly", alignItems:"center", flexDirection: "row" }}>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('home')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/Home.png')} />
          </Pressable>
          <Pressable style={styles.ativo}  onPress={()=> navigation.navigate('fornecedores')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/SupplierOn.png')} />
          </Pressable>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('cadFornecedor')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/AddSupplier.png')} />
          </Pressable>
        </View>
      </View>
      
    </View>
  );
}

const styles = StyleSheet.create({
    ativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#F27272", 
      justifyContent: "center", 
      alignItems: "center"
    }, 
    inativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#FEEFEF", 
      justifyContent: "center", 
      alignItems: "center"
    }  
  })