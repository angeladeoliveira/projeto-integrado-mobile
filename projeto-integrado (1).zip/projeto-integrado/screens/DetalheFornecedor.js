import React from 'react';
import { Text, View, Button, Image, TextInput, Pressable, StyleSheet } from 'react-native';



export default function EditarFornecedor({navigation}) {
  return (
    <View style={{backgroundColor: 'white', height: "100%"}}>
      <View style={{flex: 9, padding: 8}}>
        <View style={{flexDirection: 'row', paddingTop: 56, alignItems: 'center', marginBottom: 32, width: '100%'}}>
          <Pressable style={{flex: 1}} onPress={()=> navigation.goBack()}>
            <Image style={{height: 26, width: 26}} source={require('../assets/Back.png')} />
          </Pressable>
        
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 24, paddingLeft: 16, flex:10}}>Detalhes</Text>

          <Pressable onPress={()=> navigation.navigate('editFornecedor')} style={{alignItems: 'flex-end', flex: 3, paddingRight: 8}}>
            <Image style={{height: 26, width: 26}} source={require('../assets/Edit.png')} />
          </Pressable>
        </View>

        <View style={{borderColor: '#EBEEF2', borderWidth: 2, borderRadius: 16, paddingVertical: 32, paddingHorizontal: 40}}>
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 20, lineHeight: 25}}>Ana Amorim</Text>
          <Text style={{fontFamily: 'Roboto_500Regular', fontSize: 12, lineHeight: 15, paddingBottom: 25}}>Cerimonial</Text>
          <Text style={styles.etiqueta}>Telefone</Text>
          <Text style={styles.texto}>(xx) xxxxx-xxxx</Text>
          <Text style={styles.etiqueta}>Email</Text>
          <Text style={styles.texto}>exemplo@exemplo.com</Text>
        </View>

      </View>
      


      <View style={{flex: 1, justifyContent: "flex-end"}}>
        <View style={{height: 96, borderTopLeftRadius: 32, borderTopRightRadius: 32, borderColor: "#EBEEF2", borderWidth: 2, justifyContent: "space-evenly", alignItems:"center", flexDirection: "row" }}>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('home')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/Home.png')} />
          </Pressable>
          <Pressable style={styles.ativo}  onPress={()=> navigation.navigate('fornecedores')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/SupplierOn.png')} />
          </Pressable>
          <Pressable style={styles.inativo}  onPress={()=> navigation.navigate('cadFornecedor')}>
            <Image style={{height: 24, width: 24}} source={require('../assets/AddSupplier.png')} />
          </Pressable>
        </View>
      </View>
      
    </View>
  );
}

const styles = StyleSheet.create({
    ativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#F27272", 
      justifyContent: "center", 
      alignItems: "center"
    }, 
    inativo: {
      width: 48, 
      height: 40, 
      borderRadius: 12, 
      backgroundColor: "#FEEFEF", 
      justifyContent: "center", 
      alignItems: "center"
    }, 
    etiqueta: {
      fontFamily: 'Roboto_500Regular', 
      fontSize: 12, 
      lineHeight: 15,
      paddingBottom: 4
    },
    texto: {
      fontFamily: 'Roboto_500Regular', 
      fontSize: 16, 
      lineHeight: 20, 
      paddingBottom: 16
    }
  })
